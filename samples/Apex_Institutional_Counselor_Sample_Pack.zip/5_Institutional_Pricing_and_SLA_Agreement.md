# INSTITUTIONAL CAPACITY & PRICING AGREEMENT
1. Desk Paid Pilot (5 Urgent Drafts): $150.00 flat (100% credited to first month's retainer upon signing).
2. Desk Starter Retainer (50 Reviews / mo): $1,500.00 / month ($30/review).
3. Desk Pro Dedicated Retainer (100 Reviews / mo): $2,500.00 / month ($25/review, sub-6h SLA).
4. Enterprise Overflow Desk (150+ Reviews / mo): $3,500.00 / month (multi-seat counselor access).
