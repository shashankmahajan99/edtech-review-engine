# FERPA COMPLIANCE & STUDENT PII DATA PROTECTION ADDENDUM (DPA)
1. Cryptographic PII Scrubbing: Student names, schools, and contact details are de-identified before reviewer exposure.
2. No Model Training: Student essays are never used to train foundation models.
3. 30-Day Auto-Purge window upon counselor request.
